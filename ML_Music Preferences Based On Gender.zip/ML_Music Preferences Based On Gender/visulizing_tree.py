# STEP 1: import all from python Libraries and load the data set file "music.cvs"
# using read_csv() method
# STEP 2: assign variables X and Y to Input/Output
# STEP 3: creating an instance of the Classifier (object classifier) and assign it to variable clf=()
# STEP 4: train the Classifier with fit() method
# STEP 5: use method      tree.export_graphviz(
# out_file = 'mytreeindot.dot',
# feature_names = ['age', 'gender'],
# class_names = sorted(Y.unique()),
# label = 'all',
# rounded = True,
# filled = True)

import pandas as pd
from sklearn import tree
from sklearn.tree import DecisionTreeClassifier
from sklearn.model_selection import train_test_split


music_set = pd.read_csv('music.csv')

X = music_set.drop(columns=['genre'])

Y = music_set['genre']

X_train, X_test, Y_train, Y_test = train_test_split(X, Y, test_size=0.2)

clf = DecisionTreeClassifier()
clf = clf.fit(X_train, Y_train)

tree.export_graphviz(
 clf,
 out_file=None,
 feature_names=['age', 'gender'],
 class_names=sorted(Y.unique()),
 label='all',
 rounded=True,
 filled=True)

print(tree.export_graphviz(clf))

