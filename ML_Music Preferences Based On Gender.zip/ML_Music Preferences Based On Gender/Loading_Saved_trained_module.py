# Now lets load the saved model to use it for other prediction
# STEP 1: import libraries pandas, joblib & tree
# STEP 2: assign to a var clf the method joblib.load()
# STEP 3: make a prediction using this saved clf


import pandas as pd
from sklearn.tree import DecisionTreeClassifier
import joblib


clf = joblib.load('My_Saved_Classifier.joblib')

prediction = clf.predict([[21,1]])

print(prediction)