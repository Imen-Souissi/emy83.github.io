# Creating a basic Python program to predict the favorite user
# music based on user profile (age and gender), for this project we used the file "music.cvs"
# STEP 1: import all data and tools from python Libraries and load the data set file "music.cvs"
# using read_csv() method
# STEP 2: assign variables X and Y to Input/Output
# STEP 3: creating an instance of the Classifier (object classifier) and assign it to variable clf=()
# STEP 4: train the Classifier with fit() method
# STEP 5: Use the trained Classifier to make prediction clf.predict() method


import pandas as pd
from sklearn.tree import DecisionTreeClassifier


music_set = pd.read_csv('music.csv')


X = music_set.drop(columns = ['genre'])

Y = music_set['genre']

clf = DecisionTreeClassifier()

clf = clf.fit(X, Y)

prediction = clf.predict([[21,1]])

print(prediction)

















