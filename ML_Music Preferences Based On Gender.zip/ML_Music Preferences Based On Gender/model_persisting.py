# Model Persisting is saving a model or classifier as trained model to use
# in other situations
# STEP 1: import from python Libraries and load the data set file "music.cvs"
# using read_csv() method from pandas
# STEP 2: Assign variables X and Y to Input/Output
# STEP 3: Create an instance of the Classifier (object classifier) and assign it to variable clf=()
# STEP 4: Train the Classifier with fit() method
# STEP 6: Use joblib.dump(clf, 'name.joblib') method to save classifier and give it a name

import pandas as pd

from sklearn.tree import DecisionTreeClassifier

import joblib

music_set = pd.read_csv('music.csv')

X = music_set.drop(columns=['genre'])

Y = music_set['genre']

clf = DecisionTreeClassifier()

clf = clf.fit(X, Y)

# when you run the code a new file 'My_Saved_Classifier.joblib' will be created
# under the project directory, this file is the trained classifier which was saved
# for other reuses
joblib.dump(clf, 'My_Saved_Classifier.joblib')


