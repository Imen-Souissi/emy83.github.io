from django.urls import path
from . import views


urlpatterns = [path('', views.index),
               path('new/', views.new),      # this means exactly product/new
               path('deals/', views.deals)]       # this means exactly product/deals

